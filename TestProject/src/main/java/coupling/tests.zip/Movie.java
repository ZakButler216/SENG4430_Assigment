/**
 * Movie
 * Class with name, director, file size and duration as attributes
 * Author: Prajna Sariputra
 * Student Number: C3273420
 * E-mail Address: c3273420@uon.edu.au
 * Last Changed: 26 May 2017
 */
public class Movie
{
    private String name,director;
    private double fileSize,duration; //fileSize in MB, duration in minutes
    private static int numberOfMovies = 0; //keeps track of all Movie objects created

    /*
     * the default constructor, fills the instance variables with default values (considered empty)
     */
    public Movie()
    {
        setEmpty();
    }
    
    /*
     * an alternative constructor, this does not check whether the inputs are valid 
     */
    public Movie(String newName, String newDirector, double newFileSize, double newDuration)
    {
        set(newName, newDirector, newFileSize, newDuration);
    }
    
    /*
     * attempts to set the instance variables to the values passed as the parameter, will make sure the values are valid
     * returns:
     * 0 if successful
     * 1 if name and/or director is empty (regardless of file size and duration)
     * 2 if file size and/or duration is negative
     */
    public int setData(String newName, String newDirector, double newFileSize, double newDuration)
    {
        if (newName.equals("") || newDirector.equals("")) //if either the name or the director (or both) is blank return 1, else proceed
        {
            return 1;
        }
        if (newFileSize > 0 && newDuration > 0) //if both the file size and duration are positive, set the instance variables with the parameters and return 0, else return 2
        {
            set(newName,newDirector,newFileSize,newDuration);
            return 0;
        }
        else
        {
            return 2;
        }
    }
    
    /*
     * sets the instance variables to the parameters
     * has no validity checks
     */
    private void set(String newName, String newDirector, double newFileSize, double newDuration)
    {
        name = newName;
        director = newDirector;
        fileSize = newFileSize;
        duration = newDuration;
    }

    public String getName()
    {
        return name;
    }

    public String getDirector()
    {
        return director;
    }

    public double getFileSize()
    {
        return fileSize;
    }

    public double getDuration()
    {
        return duration;
    }
    
    public static int getNumberOfMovies()
    {
       return numberOfMovies; 
    }
    
    /*
     * increments or decrements the numberOfMovies static variable, depending on the parameter
     * true means increment, false means decrement
     */
    public static void changeNumberOfMovies(boolean increase)
    {
        if (increase == true)
        {
            numberOfMovies++;
        }
        else
        {
            numberOfMovies--;
        }
    }
    
    /*
     * adds or subtracts a positive integer, depending on the boolean parameter
     * true means add, false means subtract
     * if n is negative it will not do anything
     */
    public static void changeNumberOfMovies(boolean increase, int n)
    {
        if (increase == true)
        {
            if (n > 0)
            {
                numberOfMovies += n;
            }
        }
        else
        {
            if (n > 0)
            {
                numberOfMovies -= n;
            }
        }
    }
    
    /*
     * checks if the instance variables all have the default values, if so then return true
     */
    public boolean isEmpty()
    {
        String identifier = name + director + fileSize + duration;
        if (identifier.equals("Movie Not Found0.00.0"))
        {
            return true;
        }
        else 
        {
            return false;
        }
    }

    /*
     * sets all the instance variables to the default values (considered empty)
     */
    public void setEmpty()
    {
        name = "Movie Not Found";
        director = "";
        fileSize = 0;
        duration = 0;
    }

    /*
     * compares this Movie object with the one passed as the parameter, returns true if both are the same (name, director, file size and duration matches, name and director are case insensitive)
     */
    public boolean equals(Movie m)
    {
        String identifier = name + director + fileSize + duration; 
        String identifier1 = m.getName() + m.getDirector() + m.getFileSize() + m.getDuration();
        if (identifier.equalsIgnoreCase(identifier1)) //compare all the attributes in one go
        {
            return true;
        }
        return false;
    }

    /*
     * checks if the director instance variable of this object equals theDirector, if so then return true
     */
    public boolean equalsDirector(String theDirector)
    {
        if (director.equalsIgnoreCase(theDirector))
        {
            return true;
        }
        return false;
    }
    
}
