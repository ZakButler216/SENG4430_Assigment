/*
 * Circle
 * This defines a class which represents a two-dimensional circle in the Cartesian plane
 * Author: Prajna Sariputra
 * Student Number: 3273420
 * Course: SENG2200
 * E-mail address: c3273420@uon.edu.au
 */

import java.util.Scanner;

public class Circle extends PlanarShape {
	private Point center;
	private double radius;
	
	/*
	 * Constructor
	 * 
	 * Preconditions:
	 * The input String is in the format "x y r",
	 * where x and y are the coordinates of the center, and r is the radius
	 * Postconditions:
	 * A Circle object is created and its member variables initialized based on the input String 
	 */
	public Circle(String in) {
		Scanner input = new Scanner(in);
		double x, y;
		x = input.nextDouble();
		y = input.nextDouble();
		center = new Point(x, y);
		radius = input.nextDouble();
		input.close();
	}
	
	/*
	 * Preconditions:
	 * The member variables have been initialized properly
	 * Postconditions:
	 * A String is returned in the format "CIRC=[(x,y) r]:a",
	 * where x and y are the coordinates of the center, r is the radius and a is the area (formatted as 5.2f)
	 */
	@Override
	public String toString() {
		return "CIRC=[" + center.toString() + " " + radius + "]:" + String.format("%5.2f", area());
	}

	/*
	 * Preconditions:
	 * The radius member variable has been initialized properly
	 * Postconditions:
	 * A double is returned containing the area of the circle
	 */
	@Override
	public double area() {
		return Math.PI * Math.pow(radius, 2);
	}

	/*
	 * Preconditions:
	 * The member variables have been initialized properly
	 * Postconditions:
	 * A double is returned containing the distance of the circle from the origin
	 */
	@Override
	public double originDistance() {
		return Math.abs(center.originDistance() - radius); //distance is scalar, so make sure it will not be negative
	}

}
