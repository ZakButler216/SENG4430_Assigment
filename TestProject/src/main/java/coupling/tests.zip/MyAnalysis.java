package com.yourorganization.maven_sample;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.resolution.types.ResolvedType;
import com.github.javaparser.symbolsolver.JavaSymbolSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.JavaParserTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.ReflectionTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.JarTypeSolver;
import com.github.javaparser.ast.nodeTypes.NodeWithVariables;
import com.github.javaparser.ast.Node;
import com.github.javaparser.resolution.UnsolvedSymbolException;
import com.github.javaparser.ast.type.Type;
import com.github.javaparser.ast.ImportDeclaration;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;

public class MyAnalysis {

    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Need file path to analyse");
            return;
        }

        File file = new File(args[0]);
        // These solvers will also parse the other files around the given file as well as classes in the current JVM, plus everything in the JAR file the program is running from
        CombinedTypeSolver combinedTypeSolver = new CombinedTypeSolver();
        combinedTypeSolver.add(new ReflectionTypeSolver());
        combinedTypeSolver.add(new JavaParserTypeSolver(file.getParentFile()));
        try {
            combinedTypeSolver.add(new JarTypeSolver(new File(MyAnalysis.class.getProtectionDomain().getCodeSource().getLocation().toURI()).getPath()));
        } catch (IOException | URISyntaxException e) {
            e.printStackTrace();
        }

        // Configure JavaParser to use type resolution
        JavaSymbolSolver symbolSolver = new JavaSymbolSolver(combinedTypeSolver);
        StaticJavaParser.getConfiguration().setSymbolResolver(symbolSolver);

        // Parse some code
        CompilationUnit cu;
        try {
            cu = StaticJavaParser.parse(file);
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
            return;
        }

        findAllTypes(cu);
        System.out.println("------");
        findFieldVarType(cu);
        findVarType(cu);
        findMethodCallClass(cu);
        System.out.println("------");
        findImports(cu);
    }

    // does not include class fields
    private static void findVarType(CompilationUnit cu) {
        findVarTypeHelper(cu, VariableDeclarationExpr.class, "Declaration: ");
    }

    private static void findFieldVarType(CompilationUnit cu) {
        findVarTypeHelper(cu, FieldDeclaration.class, "Class Declaration: ");
    }

    // pass FieldDeclaration.class to find instance variables or VariableDeclarationExpr.class for local variables
    private static <T extends Node & NodeWithVariables<T>> void findVarTypeHelper(CompilationUnit cu, Class<T> cType, String printOut) {
        cu.findAll(cType).forEach(v -> { //for each expression
            //System.out.println(printOut + v);
            v.getVariables().forEach(d -> { //for each declaration
                System.out.print("Type: " + d.getType()); //arrays count as a different type
                try {
                    if (d.getType().isArrayType()) { //array types are also reference types so check it first
                        ResolvedType arrType = d.resolve().getType().asArrayType().getComponentType();
                        if (arrType.isReferenceType()) { //check in case it's an array of primitives
                            System.out.print(" (qualified name: " + arrType.asReferenceType().getQualifiedName() + ")"); //this also gets rid of the array part
                        }
                    } else if (d.getType().isReferenceType()) { //shouldn't be an array now
                        System.out.print(" (qualified name: " + d.resolve().getType().asReferenceType().getQualifiedName() + ")"); //qualified name includes both package and class name here
                    }
                } catch (UnsolvedSymbolException e) {
                    System.out.print("Unsolvable");
                } catch (UnsupportedOperationException e) {
                    System.out.print("\nwtf? " + e);
                }
                System.out.println();
            });
            System.out.println();
        });
    }

    private static void findMethodCallClass(CompilationUnit cu) {
        cu.findAll(MethodCallExpr.class).forEach(m -> { //for each method call
            //System.out.println("Method Call: " + m);
            try {
                System.out.println("Class: " + m.resolve().getPackageName() + "." + m.resolve().getClassName()); //check package name to identify Java libraries
            } catch (UnsolvedSymbolException e) {
                System.out.println("Unsolvable");
            } catch (UnsupportedOperationException e) {
                System.out.println("wtf? " + e);
            } catch (RuntimeException e) {
                System.out.println("y u do dis? " + e);
            }
            System.out.println();
        });
    }

    private static void findAllTypes(CompilationUnit cu) {
        cu.findAll(Type.class).forEach(t -> {
            try { //basically same as the inner part of findVarTypeHelper, can deduplicate
                if (t.isArrayType()) { //array types are also reference types so check it first
                    ResolvedType arrType = t.resolve().asArrayType().getComponentType();
                    if (arrType.isReferenceType()) { //check in case it's an array of primitives
                        System.out.println(arrType.asReferenceType().getQualifiedName()); //this also gets rid of the array part
                    }
                } else if (t.isReferenceType()) { //shouldn't be an array now
                    System.out.println(t.resolve().asReferenceType().getQualifiedName()); //qualified name includes both package and class name here
                }
            } catch (UnsolvedSymbolException e) {
                System.out.println("Unsolvable: " + t);
            } catch (UnsupportedOperationException e) {
                System.out.println("\nwtf? " + e);
            }
        });
    }

    // assumes that all imports are used
    private static void findImports(CompilationUnit cu) {
        cu.findAll(ImportDeclaration.class).forEach(i -> {
            System.out.print(i.getName());
            if (i.isAsterisk()) {
                System.out.print(" (package)");
            }
            System.out.println();
        });
    }
}
