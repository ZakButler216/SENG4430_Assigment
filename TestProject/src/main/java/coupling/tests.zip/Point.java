/*
 * Point
 * A class representing a two-dimensional point in the Cartesian plane
 * Author: Prajna Sariputra
 * Student Number: 3273420
 * Course: SENG2200
 * E-mail address: c3273420@uon.edu.au
 */

public class Point {
	private double x, y;
	
	/*
	 * Constructor
	 * 
	 * Preconditions:
	 * The parameters are valid double variables
	 * Postconditions:
	 * A new Point object is created with coordinates based on the input
	 */
	public Point(double newX, double newY) {
		setX(newX);
		setY(newY);
	}
	
	/*
	 * Preconditions:
	 * The x member variable has been properly initialized
	 * Postconditions:
	 * The value of the x member variable is returned
	 */
	public double getX() {
		return x;
	}
	
	/*
	 * Preconditions:
	 * The y member variable has been properly initialized
	 * Postconditions:
	 * The value of the y member variable is returned
	 */
	public double getY() {
		return y;
	}
	
	/*
	 * Preconditions:
	 * The parameter is a valid double variable
	 * Postconditions:
	 * The x member variable is set to that of the parameter
	 */
	public void setX(double newX) {
		x = newX;
	}
	
	/*
	 * Preconditions:
	 * The parameter is a valid double variable
	 * Postconditions:
	 * The y member variable is set to that of the parameter
	 */
	public void setY(double newY) {
		y = newY;
	}
	
	/*
	 * Preconditions:
	 * All member variables have been properly initialized
	 * Postconditions:
	 * A String is returned in the format "(x,y)", where x and y are the member variables formatted as 4.2f 
	 */
	@Override
	public String toString() {
		return String.format("(%4.2f,%4.2f)", x, y);
	}
	
	/*
	 * Preconditions:
	 * All member variables have been initialized
	 * Postconditions:
	 * A double is returned containing the distance of this point from the origin
	 */
	public double originDistance() {
		return Math.sqrt((x * x) + (y * y)); //just use the Pythagorean theorem here
	}
	
}
