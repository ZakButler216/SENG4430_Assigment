/*
 * SortedList
 * A class which extends LinkedList with a method to insert elements in ascending order
 * Author: Prajna Sariputra
 * Student Number: 3273420
 * Course: SENG2200
 * E-mail address: c3273420@uon.edu.au
 */

//rework start 6:45AM
public class SortedList<E extends Comparable<E>> extends LinkedList<E> {
	
	/*
	 * Preconditions:
	 * All existing items in the list is sorted in ascending order, and the input element is not null
	 * Postconditions:
	 * The new element will be inserted into the list in the appropriate spot to maintain the ascending order of the elements
	 */
	public void insertInOrder(E in) {
		if (in == null) { //do not accept a null parameter
			throw new IllegalArgumentException("Input element must not be null.");
		}
		if (size == 0 || in.compareTo(sentinel.getNext().getData()) < 0) { //if there is nothing at the moment or it is less than the first then prepend
			prepend(in);
		}
		else if (in.compareTo(sentinel.getPrev().getData()) > 0) { //if it is more than the last element then append
			append(in);
		}
		else { //otherwise it needs to be in the middle
			Node<E> current = sentinel.getNext();
			while (in.compareTo(current.getData()) > 0) { //locate the right place to insert
				current = current.getNext();
			}
			Node<E> newNode = new Node<E>(); //code below will insert before current
			newNode.setNext(current);
			newNode.setPrev(current.getPrev());
			current.getPrev().setNext(newNode);
			current.setPrev(newNode);
			newNode.setData(in);
			size++;
			modCount++;
		}
	}
}
