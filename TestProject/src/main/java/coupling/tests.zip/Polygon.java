/*
 * Polygon
 * A class representing a two-dimensional polygon in the Cartesian plane
 * Author: Prajna Sariputra
 * Student Number: 3273420
 * Course: SENG2200
 * E-mail address: c3273420@uon.edu.au
 */

//created 7:49AM 2 April
//constructor done 8:01AM 2 April + 1m
//toString + area started 1:39PM 2 April + 1m
//all done 1:54PM 2 April
import java.util.Scanner;
public class Polygon extends PlanarShape {
	
	private Point[] points;
	
	/*
	 * Constructor
	 * 
	 * Preconditions:
	 * The input String is in the format "s x1 y1 x2 y2 ...",
	 * where x and y are the coordinates of the points, and s is the number of points (or sides)
	 * Postconditions:
	 * A Polygon object is created and the points member variable initialized based on the input String 
	 */
	public Polygon(String in) {
		Scanner input = new Scanner(in);
		double x, y;
		points = new Point[input.nextInt() + 1];
		for (int counter = 0;; counter++) {
			if (input.hasNextDouble()) {
				x = input.nextDouble();
				y = input.nextDouble();
			}
			else {
				break;
			}
			points[counter] = new Point(x, y);
		}
		points[points.length - 1] = points[0];
		input.close();
	}

	/*
	 * Preconditions:
	 * The points member variable has been initialized properly
	 * Postconditions:
	 * A String is returned in the format "POLY=[(x1,y1)(x2,y2)...]:a",
	 * where x and y are the coordinates of the points and a is the area (formatted as 5.2f)
	 */
	@Override
	public String toString() {
		String out = "POLY=[";
		int endCount = points.length - 1;
		for (int counter = 0; counter < endCount; counter++) {
			out += points[counter].toString();
		}
		out += "]:" + String.format("%5.2f", area());
		return out;
	}

	/*
	 * Preconditions:
	 * The points member variable has been initialized properly
	 * Postconditions:
	 * A double is returned containing the area of the polygon
	 */
	@Override
	public double area() {
		double out = 0;
		int endCount = points.length - 1;
		for (int counter = 0; counter < endCount; counter++) {
			out += (points[counter + 1].getX() + points[counter].getX()) * (points[counter + 1].getY() - points[counter].getY());
		}
		out = Math.abs(out);
		out /= 2;
		return out;
	}

	/*
	 * This is implemented by simply returning the originDistance() of the point which is closest to the origin,
	 * so the result may not be very accurate (for instance if the polygon intersects the origin but not at any of the points
	 * then the result will not be 0)
	 * 
	 * Preconditions:
	 * The points member variable has been initialized properly
	 * Postconditions:
	 * A double is returned containing the distance of the polygon from the origin
	 */
	@Override
	public double originDistance() {
		double out = points[0].originDistance();
		int endCount = points.length - 1;
		double temp;
		for (int counter = 1; counter < endCount; counter++) {
			temp = points[counter].originDistance();
			if (temp < out) {
				out = temp;
			}
		}
		return out;
	}

}
