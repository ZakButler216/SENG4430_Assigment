/**
 * Playlist
 * Manages several Movie objects, accepts duplicate movies (same name, director, file size and duration)
 * Author: Prajna Sariputra
 * Student Number: C3273420
 * E-mail Address: c3273420@uon.edu.au
 * Last Changed: 26 May 2017
 */
public class Playlist
{
    private Movie[] movies; //id is not the same as the array index (id starts with 1, index with 0)
    private double totalTime;
    private double totalSize;
    private int playlistSize; //physical size of the playlist
    private final int DEFAULT_SIZE = 4; //default initial size as well as minimum size
    private final double MAX_TIME = 300;
    private final double MAX_SIZE = 20000; //assuming 1GB=1000MB
    private int logicalSize;
    private final int EXTEND_ARRAY_SIZE = 4;
   
    /*
     * default constructor, sets up the playlist with the default size initially
     */
    public Playlist()
    {
        initializePlaylist(DEFAULT_SIZE);
    }
    
    /*
     * constructor that sets up the playlist with the parameter as the initial size (but when shrunk the minimum size will still be the default size, and if the parameter is smaller than the default size the default size will be used instead)
     */
    public Playlist(int size)
    {
        if (size <= DEFAULT_SIZE)
        {
            initializePlaylist(DEFAULT_SIZE);
        }
        else
        {
            initializePlaylist(size);
        }
    }
    
    /*
     * initializes the movies array with the parameter as the initial size
     * can be used to reset the array as well (clear all the movies inside and set the size)
     */
    private void initializePlaylist(int size)
    {
        if (movies == null) //update the numberOfMovies static variable with the change (if the array has not been initialized yet then add the intended physical size, if it already has been initialized add or subtract the difference)
        {
            Movie.changeNumberOfMovies(true, size);
        }
        else
        {
            if (movies.length > size)
            {
                Movie.changeNumberOfMovies(false, movies.length - size);
            }
            if (movies.length < size)
            {
                Movie.changeNumberOfMovies(true, size - movies.length);
            }
        }
        movies = new Movie[size]; //initialize the array itself
        playlistSize = size;
        for (int index = 0; index < playlistSize; index++) //loop that initializes all the objects
        {
            movies[index] = new Movie();
        }
        totalTime = 0;
        totalSize = 0;
        logicalSize = 0;
    }
    
    /*
     * attempts to add a movie with the given attributes to the slot referenced by the id parameter
     * returns the result of that attempt
     * assumes that the movie attributes passed are valid (name and director are not empty, file size and duration are greater than zero), if it happens anyway an empty string will be returned
     */
    public String addMovie(String name, String director, double fileSize, double duration, int id)
    {
        Movie m = idMovie(id);
        if (m == null) //if the id is invalid return an error
        {
            return "\nChosen slot does not exist.";
        }
        if (!m.isEmpty()) //if the slot is already occupied by a movie return an error
        {
            return "\nChosen slot is already occupied.";
        }
        if (totalTime + duration > MAX_TIME || totalSize + fileSize > MAX_SIZE) //if adding the movie would cause the playlist to exceed the time/size limits return an error
        {
            return "\nPlaylist duration and/or size limit exceeded.";
        }
        if (m.setData(name, director, fileSize, duration) == 0) //if the movie was successfully added into the playlist update totalTime, totalSize and logicalSize, and return a message
        {
            totalTime += m.getDuration();
            totalSize += m.getFileSize();
            logicalSize++;
            return "\nMovie added to playlist slot " + id + ".";
        }
        return "";
    }
    
    /*
     * Searches the playlist for a movie with the given data
     * Returns an array of size playlistSize that contains ids of the movie in the playlist, if any
     * Zeros in the array should be ignored (so if the array is filled with zeros only it means that no match was found)
     */
    public int[] getMovieIds(String name, String director, double fileSize, double duration)
    {
        Movie m = new Movie(name, director, fileSize, duration);
        Movie m1;
        int[] result = new int[playlistSize];
        int id = 1, resultIndex = 0;
        while (id <= playlistSize) //the search loop
        {
            m1 = idMovie(id);
            if (m.equals(m1)) //if the selected movie is the same as the given movie save the selected movie slot id into the result array
            {
                result[resultIndex] = id;
                resultIndex++;
            }
            id++;
        }
        return result;
    }   
    
    public String getMovieName(int id)
    {
        Movie m = idMovie(id);
        if (m == null)
        {
            return "";
        }
        String o = m.getName();
        return o;
    }

    public String getMovieDirector(int id)
    {
        Movie m = idMovie(id);
        if (m == null)
        {
            return "";
        }
        String o = m.getDirector();
        return o;
    }

    public double getMovieDuration(int id)
    {
        Movie m = idMovie(id);
        if (m == null)
        {
            return 0;
        }
        double o = m.getDuration();
        return o;
    }

    public double getMovieFileSize(int id)
    {
        Movie m = idMovie(id);
        if (m == null)
        {
            return 0;
        }
        double o = m.getFileSize();
        return o;
    }
    
    public double getPlaylistDuration()
    {
        return totalTime;
    }
    
    public double getPlaylistSize()
    {
        return totalSize;
    }
    
    public int getLogicalSize()
    {
        return logicalSize;
    }
    
    public int getMaxMovies()
    {
        return playlistSize;
    }
    
    public int getDefaultMaxMovies()
    {
        return DEFAULT_SIZE;
    }
    
    /*
     * Edits all slots whose id number is in the ids array with the given attributes
     * Returns true if the change was successful or no change was made
     * Returns false if the size or duration limit was exceeded because of the edit, which means that all instances of the edited movie was deleted
     * Assumes that if the ids array has 0 as its first element it is empty, that it has no blank spaces in between, and that it is sorted in ascending order
     * Assumes that an invalid attribute (empty name or director, file size or duration less than or equal to zero) should be left unchanged
     */
    public boolean editMovie(int[] ids, String newName, String newDirector, double newFileSize, double newDuration)
    {
        if (ids[0] == 0) //if the array passed as the parameter has 0 as the first element then nothing to do (assume that it is empty)
        {
            return true;
        }
        int indexCounter = 0, changeCounter = 4;
        Movie m = idMovie(ids[0]);
        boolean sameFileSize = false, sameDuration = false;
        double fileSizeChange = 0, durationChange = 0;
        if (newName.equals("")) //if name is empty leave the current name unchanged, also decrement changeCounter
        {
            newName = m.getName();
            changeCounter--;
        }
        if (newDirector.equals("")) //if director is empty leave the current director unchanged, also decrement changeCounter
        {
            newDirector = m.getDirector();
            changeCounter--;
        }
        if (newFileSize <= 0) //if file size is empty leave the current file size unchanged, also decrement changeCounter, if not save the file size change in memory
        {
            newFileSize = m.getFileSize();
            sameFileSize = true;
            changeCounter--;
        }
        else
        {
            fileSizeChange = newFileSize - m.getFileSize();
        }
        if (newDuration <= 0) //if suration is empty leave the current duration unchanged, also decrement changeCounter, if not save the duration change in memory
        {
            newDuration = m.getDuration();
            sameDuration = true;
            changeCounter--;
        }
        else
        {
            durationChange = newDuration - m.getDuration();
        }
        if (changeCounter == 0) //if changeCounter equals zero then there is nothing to change, so stop method execution
        {
            return true;
        }
        for (int id = 1; id <= playlistSize; id++) //loop that edits all the slots referenced by the ids array, condition here will stop the loop if the end of the movies array has been reached
        {
            if (ids[indexCounter] == 0 || indexCounter >= ids.length) //if the element is zero or if the end of the ids array is reached stop loop
            {
                break;
            }
            if (!(id == ids[indexCounter])) //if the current id does not match the selected id in the ids array skip it, else increment indexCounter to select the next element in ids for the next iteration
            {
                continue;
            }
            else
            {
                indexCounter++;
            }
            m = idMovie(id);
            if (!sameFileSize) //if the file size is not the same update totalSize
            {
                totalSize += fileSizeChange;
            }
            if (!sameDuration) //if the duration is not the same update totalTime
            {
                totalTime += durationChange;
            }
            m.setData(newName, newDirector, newFileSize, newDuration); //edits the movie in the playlist (for the selected slot only)
        }
        if (totalTime > MAX_TIME || totalSize > MAX_SIZE) //if the limits are exceeded when the edit is done remove all copies of the offending movie from the playlist and return false, else return true
        {
            for (int counter = 0; counter < indexCounter; counter++) //loop that empties all slots referenced by the ids array
            {
                setSlotEmpty(ids[counter]);
            }
            return false;
        }
        else
        {
            return true;
        }
    }
    
    /*
     * returns the Movie object that the id is referring to
     */
    private Movie idMovie(int id)
    {
        if (id >= 1 && id <= playlistSize)
        {
            return movies[id - 1]; //id - 1 == index
        }
        else
        {
            return null;
        }
    }
    
    /*
     * checks if the playlist is empty or not
     * returns true if the logical size of the array is 0, false otherwise
     */
    public boolean isEmpty()
    {
        if (logicalSize == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /*
     * checks if the playlist is full or not
     * returns true if the logical size of the array equals the physical size, false otherwise
     */
    public boolean isFull()
    {
        if (logicalSize == playlistSize)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /*
     * checks if the slot referenced by the id is empty or not
     */
    public boolean isSlotEmpty(int id)
    {
        Movie m = idMovie(id);
        if (m == null)
        {
            return true;
        }
        return m.isEmpty();
    }

    /*
     * searches the playlist for any slot that contains the movie that is passed as the parameter (the attributes themselves, not the object)
     * returns true if at least one movie in the playlist has the same name, director, file size and duration as specified
     */
    public boolean isDuplicate(String newName, String newDirector, double newFileSize, double newDuration)
    {
        Movie m = new Movie(newName, newDirector, newFileSize, newDuration);
        Movie m1;
        int id = 1;
        while (id <= playlistSize) //loop that searches the playlist for the specified movie
        {
            m1 = idMovie(id);
            if (m.equals(m1)) //if a match is found return true immediately (don't need to know how many)
            {
                return true;
            }
            id++;
        }
        return false;
    }

    /*
     * sets the slot referenced by the id empty (in effect "removes" the movie from the playlist), also updates totaltime, totalSize and logicalSize
     */
    public void setSlotEmpty(int id)
    {
        Movie m = idMovie(id);
        if (m == null)
        {
            return;
        }
        totalTime -= m.getDuration();
        totalSize -= m.getFileSize();
        logicalSize--;
        m.setEmpty();
    }

    /*
     * sets the entire playlist as empty, simply calls the initializePlaylist with DEFAULT_SIZE as the parameter
     */
    public void setEmpty()
    {
        initializePlaylist(DEFAULT_SIZE);
    }

    /*
     * sets the playlist empty if at least one movie in the playlist matches the given movie
     * returns true if successful, false if not
     */
    public boolean removeMovieAndPlaylist(String name, String director, double fileSize, double duration)
    {
        Movie m = new Movie(name, director, fileSize, duration);
        Movie m1;
        int id = 1;
        while (id <= playlistSize)
        {
            m1 = idMovie(id);
            if (m.equals(m1))
            {
                setEmpty();
                return true;
            }
            id++;
        }
        return false;
    }
    
    /*
     * the two methods extendArray and shrinkArray are ways to allow other classes to resize the array without letting them gain access to the allMovies array directly
     */
    public void extendArray()
    {
        movies = resizeArray(true, movies);
    }
    
    public void shrinkArray()
    {
        movies = resizeArray(false, movies);
    }
    
    /*
     * resizes a Movie array, has two modes
     * extend mode (extend is true) will extend the array by EXTEND_ARRAY_SIZE
     * extend mode assumes that the input array is full
     * shrink mode (extend is false) will either reduce the array to half its current size or the default size, whichever is larger
     * shrink mode will not preserve any empty slots in between filled ones (movies in slots 1,3,5 will be moved to slots 1,2,3 after the resize for example)
     * shrink mode assumes that the logical size of the input array is less than half the physical size
     */
    private Movie[] resizeArray(boolean extend, Movie[] array)
    {
        Movie[] result;
        if (extend) //selects the mode, if true then extends the array, else it shrinks the array
        {
            result = new Movie[array.length + EXTEND_ARRAY_SIZE]; //create an array of the new size
            int counter = 0;
            for (;counter < array.length; counter++) //loop that copies the elements of the original array into the extended array, preserving order
            {
                result[counter] = array[counter];
            }
            int endCounter = counter + EXTEND_ARRAY_SIZE;
            for (;counter < endCounter; counter++) //loop that initializes the newly added elements
            {
                result[counter] = new Movie();
            }
            Movie.changeNumberOfMovies(true, EXTEND_ARRAY_SIZE); //update the numberOfMovies static variable in the Movie class
        }
        else
        {
            int counter = 0, resultIndex = 0, endSize;
            if (array.length % 2 == 0) //checks if the physical size of the array is an even number
            {
                endSize = Math.max(array.length / 2, DEFAULT_SIZE); //decides whether to halve the size of the array or set it to the default size, whichever is higher
                Movie.changeNumberOfMovies(false, array.length - endSize); //update the numberOfMovies static variable in the Movie class
                result = new Movie[endSize];
                for (;counter < array.length; counter++) //loop that copies the non-empty elements from the original array to the new one
                {
                    if (!array[counter].isEmpty()) //checks if the movie to be copied is empty, copies it if true
                    {
                        result[resultIndex] = array[counter];
                        resultIndex++;
                    }
                }
                for (;resultIndex < result.length; resultIndex++) //initializes remaining objects, if any
                {
                    result[resultIndex] = new Movie();
                }
            }
            else
            {
                endSize = Math.max((array.length / 2) + 1, DEFAULT_SIZE); //decides whether to halve the size of the array (rounded up) or set it to the default size, whichever is higher
                Movie.changeNumberOfMovies(false, array.length - endSize); //update the numberOfMovies static variable in the Movie class
                result = new Movie[endSize];
                for (;counter < array.length; counter++) //loop that copies the non-empty elements from the original array to the new one
                {
                    if (!array[counter].isEmpty()) //checks if the movie to be copied is empty, copies it if true
                    {
                        result[resultIndex] = array[counter];
                        resultIndex++;
                    }
                }
                for (;resultIndex < result.length; resultIndex++) //initializes remaining objects, if any
                {
                    result[resultIndex] = new Movie();
                }
            }
        }
        playlistSize = result.length; //update the playlistSize variable
        return result;
    }
}
