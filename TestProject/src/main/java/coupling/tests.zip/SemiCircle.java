/*
 * SemiCircle
 * A class representing a two-dimensional semicircle in the Cartesian plane
 * Author: Prajna Sariputra
 * Student Number: 3273420
 * Course: SENG2200
 * E-mail address: c3273420@uon.edu.au
 */

import java.util.Scanner;

public class SemiCircle extends PlanarShape {
	private Point baseCenter;
	private Point otherPoint; //point at the end of the perpendicular to the base
	
	/*
	 * Constructor
	 * 
	 * Preconditions:
	 * The input String is in the format "x1 y1 x2 y2",
	 * where x1 and y1 are the coordinates of the point at the center of the base,
	 * while x2 and y2 are the coordinates of the point at the end of the perpendicular to the base
	 * Postconditions:
	 * A SemiCircle object is created and the member variables initialized based on the input String 
	 */
	public SemiCircle(String in) {
		Scanner input = new Scanner(in);
		double x, y;
		x = input.nextDouble();
		y = input.nextDouble();
		baseCenter = new Point(x, y);
		x = input.nextDouble();
		y = input.nextDouble();
		otherPoint = new Point(x, y);
		input.close();
	}
	
	/*
	 * Preconditions:
	 * The member variables have been initialized properly
	 * Postconditions:
	 * A String is returned in the format "SEMI=[(x1,y1)(x2,y2)]:a",
	 * where x1 and y1 are the coordinates of the point at the center of the base,
	 * while x2 and y2 are the coordinates of the point at the end of the perpendicular to the base,
	 * and a is the area (formatted as 5.2f)
	 */
	@Override
	public String toString() {
		return "SEMI=[" + baseCenter.toString() + otherPoint.toString() + "]:" + String.format("%5.2f", area());
	}

	/*
	 * Preconditions:
	 * The member variables have been initialized properly
	 * Postconditions:
	 * A double is returned containing the area of the semicircle
	 */
	@Override
	public double area() {
		double deltaX = baseCenter.getX() - otherPoint.getX();
		double deltaY = baseCenter.getY() - otherPoint.getY();
		double radius = Math.sqrt(Math.pow(deltaX, 2) + Math.pow(deltaY, 2));
		return (1.0 / 2.0) * Math.PI * Math.pow(radius, 2);
	}

	/*
	 * This is implemented by simply returning the originDistance() of either one of the two data points or
	 * one of the two base extremity points, whichever is closest to the origin, so the result may not be very accurate
	 * (for instance if the semicircle intersects the origin but not at any of the four points then the result will not be 0)
	 * 
	 * Preconditions:
	 * The member variables have been initialized properly
	 * Postconditions:
	 * A double is returned containing the distance of the semicircle from the origin
	 */
	@Override
	public double originDistance() {
		double[] distances = new double[3];
		distances[0] = otherPoint.originDistance();
		double deltaX = baseCenter.getX() - otherPoint.getX();
		double deltaY = baseCenter.getY() - otherPoint.getY();
		double m = -(deltaX / deltaY); //slope of the base
		double radius = Math.sqrt(Math.pow(deltaX, 2) + Math.pow(deltaY, 2));
		deltaX = Math.sqrt(Math.pow(radius, 2) / (Math.pow(m, 2) + 1)); //dx^2 + dy^2 = r^2, m = dy / dx
		deltaY = m * deltaX;
		Point baseExtremity = new Point(baseCenter.getX() + deltaX, baseCenter.getY() + deltaY);
		distances[1] = baseExtremity.originDistance();
		baseExtremity = new Point(baseCenter.getX() - deltaX, baseCenter.getY() - deltaY);
		distances[2] = baseExtremity.originDistance();
		double smallest = baseCenter.originDistance(); //start with one of the four to compare with the other three
		for (int counter = 0; counter < distances.length; counter++) {
			if (distances[counter] < smallest) {
				smallest = distances[counter];
			}
		}
		return smallest;
	}

}
