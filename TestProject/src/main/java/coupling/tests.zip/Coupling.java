package main.java.coupling;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.resolution.types.ResolvedType;
import com.github.javaparser.symbolsolver.JavaSymbolSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.JavaParserTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.ReflectionTypeSolver;
import com.github.javaparser.ast.nodeTypes.NodeWithVariables;
import com.github.javaparser.ast.Node;


public class Coupling
{
    private final CompilationUnit cu;
    private String content;

    public Coupling(CompilationUnit newCu)
    {
        cu = newCu;
        content = cu.getChildNodes().toString();
        findFieldVarType(cu);
        findVarType(cu);
        findMethodCallClass(cu);
        printContent();
    }

    public void printContent()
    {
        System.out.println("/////////// start //////////");
        System.out.println(content);
    }

    private static void findMethodCallClass(CompilationUnit cu) {
        cu.findAll(MethodCallExpr.class).forEach(m -> { //for each method call
            System.out.println("Method Call: " + m);
            System.out.println(m.resolve());
            System.out.println("Class: " + m.resolve().getPackageName() + "." + m.resolve().getClassName()); //check package name to identify Java libraries
            System.out.println();
        });
    }

    // does not include class fields
    private static void findVarType(CompilationUnit cu) {
        findVarTypeHelper(cu, VariableDeclarationExpr.class);
    }

    private static void findFieldVarType(CompilationUnit cu) {
        findVarTypeHelper(cu, FieldDeclaration.class);
    }

    // pass FieldDeclaration.class to find instance variables or VariableDeclarationExpr.class for local variables
    private static <T extends Node & NodeWithVariables<T>> void findVarTypeHelper(CompilationUnit cu, Class<T> cType) {
        cu.findAll(cType).forEach(v -> { //for each expression
            System.out.println("Class Declaration: " + v);
            v.getVariables().forEach(d -> { //for each declaration
                System.out.print("Type: " + d.getType()); //arrays count as a different type
                if (d.getType().isReferenceType()) {
                    if (d.getType().isArrayType()) { //array of references is both but if so we can't convert to a reference type directly
                        System.out.print(" (qualified name: " + d.resolve().getType().asArrayType().getComponentType().asReferenceType().getQualifiedName() + ")"); //this also gets rid of the array part
                    } else {
                        System.out.print(" (qualified name: " + d.resolve().getType().asReferenceType().getQualifiedName() + ")"); //qualified name includes both package and class name here
                    }
                }
                System.out.println();
            });
            System.out.println();
        });
    }
}
