/**
 * Interface
 * Manages a MovieDatabase object and several Playlist objects, as well as taking user input
 * Author: Prajna Sariputra
 * Student Number: C3273420
 * E-mail Address: c3273420@uon.edu.au
 * Last Changed: 26 May 2017
 */
import java.util.*;
import java.io.*;

public class Interface {
    private MovieDatabase database = new MovieDatabase();
    private Scanner console = new Scanner(System.in);
    private Playlist[] playlists; //id is not the same as the array index (id starts with 1, index with 0)
    private final int DEFAULT_PLAYLIST_AMOUNT = 2; //default initial size as well as minimum size
    private int playlistAmount; //physical size of the playlist database
    private int logicalSize = 0;
    private final int PLAYLIST_EXTEND_ARRAY_SIZE = 2;
    private PrintWriter outputStream;
    private Scanner inputStream;
    
    private void run() {
        initializePlaylists();
        boolean noPlaylistCreated = true;
        mainloop: for (char input;;) //main program loop
        {
            if (database.isEmpty()) //attempts to make sure that the database is not empty
            {
                databaseIsEmpty();
            }
            if (logicalSize == 0) //asks the user if he/she wants to make a playlist
            {
                noPlaylistCreated = playlistsAreEmptyAndLeaveEmpty();
            }
            if (noPlaylistCreated) //decides whether the playlist management options are shown or not
            {
                for(;;) //loop that runs while no playlists are present, contains a variant of the user interface without the playlist management options
                {
                    if (database.isEmpty()) //also attempts to ensure that the database is not empty
                    {
                        databaseIsEmpty();
                    }
                    System.out.println("\na. List all movies in the database");
                    System.out.println("b. List all movies with the same director");
                    System.out.println("c. List all movies whose duration is under a certain time");
                    System.out.println("d. Add movies to the database");
                    System.out.println("e. Edit a movie in the database");
                    System.out.println("f. Create a playlist");
                    System.out.println("g. Delete a movie from the database");
                    System.out.println("h. Load a movie database from a file");
                    System.out.println("i. Save a movie database to a file");
                    System.out.println("x. Exit");
                    System.out.print("\nOption: ");
                    input = console.next().charAt(0);
                    switch (input)
                    {
                        case 'a':   listMovies();
                                    break;
                        case 'b':   listMoviesByDirector();
                                    break;
                        case 'c':   listMoviesUnderDuration();
                                    break;
                        case 'd':   addMovies();
                                    break;
                        case 'e':   editMovie();
                                    break;
                        case 'f':   addMoviesToPlaylist(playlists[0]);
                                    noPlaylistCreated = false;
                                    continue mainloop;
                        case 'g':   removeMovie();
                                    break;
                        case 'h':   loadDatabase();
                                    break;
                        case 'i':   saveDatabase();
                                    break;
                        case 'x':   System.exit(0);
                        default:    System.out.println("Invalid option.");
                                    break;
                    }
                }
            }
            else //the main user interface with all options
            {
                System.out.println("\na. List all movies in the database");
                System.out.println("b. List all movies with the same director");
                System.out.println("c. List all movies whose duration is under a certain time");
                System.out.println("d. List all playlists and the respective movies");
                System.out.println("e. List the movies in one playlist");
                System.out.println("f. Add movies to the database");
                System.out.println("g. Edit a movie in the database and any associated playlist(s)");
                System.out.println("h. Create another playlist");
                System.out.println("i. Add movies to an existing playlist");
                System.out.println("j. Delete a movie from the database and any associated playlist(s)");
                System.out.println("k. Delete a movie from a playlist");
                System.out.println("l. Delete a playlist");
                System.out.println("m. Load a movie database from a file");
                System.out.println("n. Save a movie database to a file");
                System.out.println("x. Exit");
                System.out.print("\nOption: ");
                input = console.next().charAt(0);
                switch (input)
                {
                    case 'a':   listMovies();
                                break;
                    case 'b':   listMoviesByDirector();
                                break;
                    case 'c':   listMoviesUnderDuration();
                                break;
                    case 'd':   listAllPlaylistsAndContents();
                                break;
                    case 'e':   listOnePlaylistAndContents();
                                break;
                    case 'f':   addMovies();
                                break;
                    case 'g':   editMovie();
                                break;
                    case 'h':   addMoviesToNextPlaylist();
                                break;
                    case 'i':   addMoviesToAPlaylist();
                                break;
                    case 'j':   removeMovie();
                                break;
                    case 'k':   removeMovieFromAPlaylist();
                                break;
                    case 'l':   removePlaylist();
                                break;
                    case 'm':   loadDatabase();
                                break;
                    case 'n':   saveDatabase();
                                break;
                    case 'x':   System.exit(0);
                    default:    System.out.println("Invalid option.");
                                break;
                }
            }
        }
    }
    
    /*
     * method to intitalize the playlist array and its contents
     * can also be used to reset the playlist array (default size)
     */
    private void initializePlaylists()
    {
        playlists = new Playlist[DEFAULT_PLAYLIST_AMOUNT]; //initialize playlist array
        playlistAmount = DEFAULT_PLAYLIST_AMOUNT;
        for (int index = 0; index < playlistAmount; index++) //initialize playlist array contents
        {
            playlists[index] = new Playlist();
        }
    }
    
    /*
     * asks the user to add movies into the database, either manually or by loading a database from a file
     * if the method completes executing it means that the database has at least one movie
     */
    private void databaseIsEmpty()
    {
        for(char input;;) //loop to keep asking user until valid input is given and at least one movie has been added to the database
        {
            System.out.println("\nType x to exit.");
            System.out.println("The movie database is empty at the moment.");
            System.out.println("Would you like to load a movie database from a file? (y/n)");
            input = console.next().charAt(0);
            switch(input)
            {
                case 'n':   if (!addMovies()) //if the user chooses not to load from file then user will be asked to add movies manually, if no movies were added successfully then continue loop, else end method execution
                            {
                                continue;
                            }
                            else
                            {
                                return;
                            }
                case 'y':   if (!loadDatabase()) //if the user chooses to load from file but no movies were successfully loaded continue the loop, else end method execution
                            {
                                continue;
                            }
                            else
                            {
                                return;
                            }
                case 'x':   System.exit(0);
                default:    System.out.println("Invalid option.");
            }
        }
    }
    
    /*
     * returns false if a playlist was created (and is not empty) after the method executes, true otherwise
     * true means that the user likely intended to not create any playlists when asked
     * so if this method was called when there are no playlists and true was returned it means that there still are no playlists
     */
    private boolean playlistsAreEmptyAndLeaveEmpty()
    {
        for(char input;;) //loop to keep asking user until valid input is received
        {
            System.out.println("\nThere are no playlists at the moment.");
            System.out.println("Would you like to create a playlist? (y/n)");
            input = console.next().charAt(0);
            switch(input)
            {
                case 'y':   if (addMoviesToPlaylist(playlists[0])) //if called method returns true then return false, return true otherwise
                            {
                                return false;
                            }
                            else
                            {
                                return true;
                            }
                case 'n':   return true;
                default:    System.out.println("Invalid option.");
            }
        }
    }
    
    /*
     * called to check whether the playlist database should be automatically shrunk
     * assumes that an empty playlist database is already at its default size
     */
    private void autoShrinkPlaylistDatabase()
    {
        boolean playlistsShrunk = false;
        if (logicalSize == 0 || playlistAmount == DEFAULT_PLAYLIST_AMOUNT) //do nothing if the playlist database is empty or the physical size of the playlist database is the same as the default size
        {
            return;
        }
        if (playlistAmount % 2 == 0) //checks whether the physical size is an even number
        {
            if (logicalSize < playlistAmount / 2) //if the physical size is even then straightforward integer division is ok
            {
                playlists = resizeArray(false, playlists);
                playlistsShrunk = true;
            }
        }
        else
        {
           if (logicalSize < (playlistAmount / 2) + 1) //if the physical size is an odd number round the number up (add 1 because integer division simply removes the decimals)
            {
                playlists = resizeArray(false, playlists);
                playlistsShrunk = true;
            } 
        }
        if (playlistsShrunk) //if the playlist database was actually shrunk then report to user
        {
            System.out.println("\nThe playlist database has been automatically shrunk.");
            System.out.println("Playlist numbers may have changed because of this.");
        }
    }
    
    /*
     * called to check whether the movie database should be shrunk
     * works the same as the autoShrinkPlaylistDatabase method and shares the same assumption, except it operates on the movie database
     */
    private void autoShrinkMovieDatabase()
    {
        boolean databaseShrunk = false;
        if (database.getLogicalSize() == 0 || database.getMaxMovies() == database.getDefaultMaxMovies())
        {
            return;
        }
        if (database.getMaxMovies() % 2 == 0)
        {
            if (database.getLogicalSize() < database.getMaxMovies() / 2)
            {
                database.shrinkArray();
                databaseShrunk = true;
            }
        }
        else
        {
           if (database.getLogicalSize() < (database.getMaxMovies() / 2) + 1)
            {
                database.shrinkArray();
                databaseShrunk = true;
            } 
        }
        if (databaseShrunk)
        {
            System.out.println("\nThe movie database has been automatically shrunk.");
            System.out.println("Movie id numbers may have changed because of this.");
        }
    }
    
    /*
     * called to check if the playlist passed as the parameter should be shrunk
     * works the same as the autoShrinkPlaylistDatabase method and shares the same assumption, except it operates on the playlist passed as the parameter
     */
    private void autoShrinkPlaylist(Playlist p)
    {
        boolean playlistShrunk = false;
        if (p.getLogicalSize() == 0 || p.getMaxMovies() == p.getDefaultMaxMovies())
        {
            return;
        }
        if (playlistAmount % 2 == 0)
        {
            if (p.getLogicalSize() < p.getMaxMovies() / 2)
            {
                p.shrinkArray();
                playlistShrunk = true;
            }
        }
        else
        {
           if (p.getLogicalSize() < (p.getMaxMovies() / 2) + 1)
            {
                p.shrinkArray();
                playlistShrunk = true;
            } 
        }
        if (playlistShrunk)
        {
            System.out.println("\nThe modified playlist has been automatically shrunk.");
        }
    }
    
    /*
     * returns true if the database is not empty after the method executes, false otherwise
     * if the method was called when the database is empty and true was returned it means that at least one movie was successfully added
     */
    private boolean addMovies()
    {
        boolean success = false;
        if (database.isFull()) //if the database is full extend the movie database
        {
            database.extendArray();
        }
        for(;;) //loop to keep adding movies until the user decides to stop
        {
            System.out.println("\nIf you would like to stop adding movies, type -1 as the title.");
            System.out.print("Please input the title of the movie: ");
            /*
             * console.nextLine() is called twice to clear the buffer first
             * this method always runs after console.next() or nextInt() was called, so if nextLine() was only called once
             * it would only return the rest of the buffer, which is not the intended behaviour here
             */
            console.nextLine();
            String newName = console.nextLine();
            if (newName.equals("-1"))
            {
                return success;
            }
            System.out.print("Please input the director of the movie: ");
            String newDirector = console.nextLine();
            System.out.print("Please input the length of the movie in minutes: ");
            double newDuration = console.nextDouble();
            System.out.print("Please input the file size of the movie in megabytes: ");
            double newFileSize = console.nextDouble();
            System.out.println("\n" + database.addMovie(newName, newDirector, newFileSize, newDuration));
            if (!database.isEmpty()) //if the database is not empty it means the user had successfully added a movie at one point and it's still there
            {
                success = true;
            }
            if (database.isFull()) //if the user added movies until the database is full extend it
            {
                database.extendArray();
            }
        }
    }
    
    /*
     * edits a movie in the database based on user input
     * will also edit the referenced movie in the playlists as well, if the edit does not cause the playlist(s) to go beyond the time/size limit (will remove the movie from the playlist(s) if the limits are exceeded)
     */
    private void editMovie()
    {
        int id;
        String newName, newDirector;
        double newFileSize, newDuration;
        for (;;) //loop to ask user which movie to edit, will continue until user inputs a valid id number
        {
            listMovies();
            System.out.println("\nTo cancel, type -1 as the ID.");
            System.out.print("Type the ID of the movie you wish to edit: ");
            id = console.nextInt();
            if (id == -1)
            {
                return;
            }
            if (database.isMovieEmpty(id)) //if the user inputs an ID number that refers to a nonexistent movie (implemented as an empty Movie object) tell user and continue loop
            {
                System.out.println("Invalid movie selected.");
                continue;
            }
            break;
        }
        System.out.println("\nTo leave the name or director unchanged, leave the field blank.");
        System.out.println("To leave the file size or duration unchanged, type 0 or a negative number.");
        System.out.println("Selected Movie: " + getMovieDataFromDatabase(id));
        System.out.println("New name: ");
        console.nextLine();
        newName = console.nextLine();
        System.out.println("New director: ");
        newDirector = console.nextLine();
        System.out.println("New duration (in minutes): ");
        newDuration = console.nextDouble();
        System.out.println("New file size (in MB): ");
        newFileSize = console.nextDouble();
        String oldName = database.getMovieName(id); //save the original movie attributes in memory
        String oldDirector = database.getMovieDirector(id);
        double oldFileSize = database.getMovieFileSize(id);
        double oldDuration = database.getMovieDuration(id);
        if (database.isDuplicate(newName, newDirector, newFileSize, newDuration)) //if the movie with the new attributes is already present tell user and stop method execution
        {
            System.out.println("\nMovie with the new attributes already exist in the database.");
            return;
        }
        String o = database.editMovie(id, newName, newDirector, newFileSize, newDuration); //edits the movie in the database
        System.out.println("\n" + o); //prints whether the movie was actually changed in the database
        if (o.equals("Movie unchanged.")) //if no change was made skip the rest of the method
        {
            return;
        }
        int[] ids;
        Playlist p;
        boolean wasAPlaylistRemoved = false;
        for (int playlistId = 1; playlistId <= playlistAmount; playlistId++) //loop that searches all playlists for the movie and edits them or removes them if the limits were exceeded as a result
        {
            p = idPlaylist(playlistId);
            if (p.isEmpty()) //if the playlist is empty skip it
            {
                continue;
            }
            ids = p.getMovieIds(oldName, oldDirector, oldFileSize, oldDuration); //search the selected playlist for the movie
            if (!p.editMovie(ids, newName, newDirector, newFileSize, newDuration)) //if the edit was unsuccessful (movie had to be removed) report to user
            {
                System.out.println("Edited movie removed from Playlist " + playlistId + " due to exceeding size and/or time limits.");
                if (p.isEmpty()) //checks if the playlist became empty after the movie is removed from the playlist
                {
                    wasAPlaylistRemoved = true;
                }
            }
        }
        if (wasAPlaylistRemoved) //if at least one playlist became empty then "remove" them automatically and inform user
        {
            System.out.println("Empty playlist(s) detected, it has been automatically removed.");
        }
    }
    
    /*
     * asks user which movies to add to the given playlist, extends it if the playlist is already full (but only when the method is initially called)
     * returns true if the playlist that was passed as the parameter exists (isn't empty) after the method has executed
     * returns false otherwise
     * if the playlist was nonexistent (empty) before the method executed and true was returned it means that the playlist was successfully created
     */
    private boolean addMoviesToPlaylist(Playlist p)
    {
        if (p.isFull()) //if the playlist referenced by the parameter is full extend it, inform the user and proceed
        {
            p.extendArray();
            System.out.println("\nThe selected playlist has been extended.");
            return addMoviesToPlaylistCore(p);
        }
        else
        {
            return addMoviesToPlaylistCore(p);
        }
    }
    
    /*
     * should not be called directly, use addMoviesToPlaylist(Playlist p) instead
     */
    private boolean addMoviesToPlaylistCore(Playlist p)
    {
        boolean initiallyEmpty = false;
        if (p.isEmpty()) //if selected playlist was nonexistent (implemented as an empty Playlist object) tell user that a new playlist has been "created"
        {
            System.out.println("\nPlaylist created.");
            logicalSize++;
            initiallyEmpty = true;
        }
        int id, slotId;
        char input;
        boolean success = false;
        wholeloop: while (!p.isFull()) //keep adding movies until the playlist is full
        {
            listMovies();
            System.out.println("\nTo stop adding movies to the playlist, type -1 as the movie ID.");
            System.out.println("To increase the number of slots, fill all the existing ones and try to add another movie into this playlist.");
            System.out.print("Enter the ID number of the movie you wish to add: ");
            id = console.nextInt();
            if (id == -1)
            {
                if (initiallyEmpty && !success) //if no movies were added to the playlist and it is still empty tell user that it has been "removed" (since empty playlists are considered nonexistent)
                {
                    System.out.println("\nEmpty playlist detected, it has been removed automatically.");
                    logicalSize--;
                }
                return success;
            }
            if (!database.isMovieEmpty(id) && p.isDuplicate(database.getMovieName(id), database.getMovieDirector(id), database.getMovieFileSize(id), database.getMovieDuration(id))) //check if the movie is already present in the playlist and if the id refers to an actual movie, inform user if so (but doesn't prevent)
            {
                duplicateloop: for (;;) //loop to keep asking user for an acceptable answer until one is given
                {
                    System.out.println("\nThis movie is already in the playlist. Do you still want to add it? (y/n)");
                    input = console.next().charAt(0);
                    switch(input)
                    {
                        case 'y':   break duplicateloop;
                        case 'n':   continue wholeloop;
                        default:    System.out.println("Invalid option.");
                    }
                }
            }
            if ((id >= 1 && id <= database.getMaxMovies()) && !database.isMovieEmpty(id)) //if the id is valid and and the id refers to an actual movie ask user which slot to add the movie in, else tell user that the selected movie does not exist
            {
                listPlaylistContents(p);
                System.out.print("\nEnter the number of the slot you wish to add the movie into: ");
                slotId = console.nextInt();
                System.out.println(p.addMovie(database.getMovieName(id), database.getMovieDirector(id), database.getMovieFileSize(id), database.getMovieDuration(id), slotId)); //attempts to add the movie into the selected slot and displays the result (could be success or an error)
                if (!p.isEmpty())
                {
                    success = true;
                }
            }
            else
            {
                System.out.println("\nSelected movie does not exist.");
            }
        }
        return true;
    }
    
    /*
     * ask user which playlist he/she wants to add movies to, then call addMoviesToPlaylist
     */
    private void addMoviesToAPlaylist()
    {
        Playlist p = selectPlaylist(); //asks user which playlist to modify
        if (p == null)
        {
            return;
        }
        addMoviesToPlaylist(p);
    }
    
    /*
     * adds movies to the next empty playlist ("creates" a playlist from the user's point of view)
     */
    private void addMoviesToNextPlaylist()
    {
        if (logicalSize == playlistAmount) //if the playlist database is full extend it, inform the user and proceed
        {
            playlists = resizeArray(true, playlists);
            System.out.println("\nThe playlist database has been extended.");
            addMoviesToNextPlaylistCore();
        }
        else
        {
            addMoviesToNextPlaylistCore();
        }
    }
    
    /*
     * should not be called directly, use addMoviesToNextPlaylist() instead
     */
    private void addMoviesToNextPlaylistCore()
    {
       int id = 1;
       Playlist p;
       while (id <= playlistAmount) //loop that searches for an empty playlist, once found it calls addMoviesToPlaylist and stops
       {
            p = idPlaylist(id);
            if (p.isEmpty()) //if the selected playlist is empty then call addMoviesToPlaylist with the selected playlist as the parameter
            {
                addMoviesToPlaylist(p);
                return;
            }
            id++;
       }
    }
    
    /*
     * deletes a movie from the database and any playlists which contain that movie
     */
    private void removeMovie()
    {
        int id;
        for (;;) //loop which will keep running until the user provides a valid id number
        {
            listMovies();
            System.out.println("\nTo cancel, type -1 as the ID number.");
            System.out.print("Enter the ID number of the movie you wish to remove: ");
            id = console.nextInt();
            if (id == -1)
            {
                return;
            }
            if (database.isMovieEmpty(id)) //if the id does not refer to any existing movie tell user and continue the loop
            {
                System.out.println("\nMovie with ID number " + id + " does not exist.");
                continue;
            }
            break;
        }
        int playlistId = 1;
        Playlist p;
        String name = database.getMovieName(id);
        String director = database.getMovieDirector(id);
        double fileSize = database.getMovieFileSize(id);
        double duration = database.getMovieDuration(id);
        System.out.println();
        while (playlistId <= playlistAmount) //loop that searches all playlists for the movie and removes any movie with that playlist
        {
            p = idPlaylist(playlistId);
            if (p.removeMovieAndPlaylist(name, director, fileSize, duration))
            {
                System.out.println("Playlist " + playlistId + " deleted.");
                logicalSize--;
            }
            playlistId++;
        }
        System.out.println(database.removeMovie(id));
        autoShrinkMovieDatabase(); //check if the movie database would need to be shrunk
        autoShrinkPlaylistDatabase(); //check if the playlist database would need to be shrunk
    }
    
    /*
     * removes a movie from a playlist (but not from the database)
     */
    private void removeMovieFromPlaylist(Playlist p)
    {
        int slotId;
        for (;;) //loop to keep asking user until a valid id number is given
        {
            listPlaylistContents(p);
            System.out.println("\nTo cancel, type -1 as the slot number.");
            System.out.print("Type the number of the slot which contains the movie you wish to remove: ");
            slotId = console.nextInt();
            if (slotId == -1)
            {
                return;
            }
            if (slotId > p.getMaxMovies() || slotId < 1 || p.isSlotEmpty(slotId)) //check if the slot id the user input is valid, if not tell user and continue the loop, if it is valid break the loop
            {
                System.out.println("\nSelected slot does not exist or is already empty.");
            }
            else
            {
                break;
            }
        }
        p.setSlotEmpty(slotId); //removes the selected movie from the playlist
        System.out.println("\nMovie removed from slot " + slotId + ".");
        if (p.isEmpty()) //if the playlist became empty after the movie was removed tell user that the playlist has been "removed"
        {
            System.out.println("Empty playlist detected, it has been removed automatically.");
            logicalSize--;
        }
        autoShrinkPlaylist(p); //check if the playlist needs to be shrunk
    }
    
    /*
     * asks the user which playlist to modify, then calls removeMovieFromPlaylist
     */
    private void removeMovieFromAPlaylist()
    {
        Playlist p = selectPlaylist(); //asks user which playlist to modify
        if (p == null)
        {
            return;
        }
        removeMovieFromPlaylist(p);
    }
    
    /*
     * "removes" a playlist (implemented as setting the playlist as an empty playlist, which is considered as nonexistent)
     */
    private void removePlaylist()
    {
        Playlist p = selectPlaylist(); //asks user which playlist to modify
        if (p == null)
        {
            return;
        }
        p.setEmpty(); //empties the playlist
        System.out.println("\nPlaylist removed.");
        logicalSize--;
        autoShrinkPlaylistDatabase(); //check if the playlist database should be shrunk
    }
    
    /*
     * lists all the movies in the database
     */
    private void listMovies()
    {
        System.out.println("\nList of movies in the database:\n");
        int id = 1;
        while (id <= database.getMaxMovies()) //loop that prints all movies in the database, one on each line (if the movie with the selected id is nonexistent print nothing)
        {
            System.out.print(getMovieDataFromDatabase(id));
            id++;
        }
    }
    
    /*
     * searches for movies that match the director name given by the user in the database, then shows the results
     */
    private void listMoviesByDirector()
    {
        System.out.println("\nTo cancel, leave the name blank.");
        System.out.println("Enter the name of the director:");
        console.nextLine();
        String theDirector = console.nextLine();
        if (theDirector.equals(""))
        {
            return;
        }
        int id = 1;
        boolean matchFound = false;
        System.out.println();
        while (id <= database.getMaxMovies()) //loop that searches the database for matches and prints the movies that match
        {
            if (database.movieEqualsDirector(theDirector, id))
            {
                System.out.print(getMovieDataFromDatabase(id));
                matchFound = true;
            }
            id++;
        }
        if (matchFound == false) //if no matching movies were found tell user
        {
            System.out.println("No movies with director \"" + theDirector + "\" found in the database.");
        }
    }
    
    /*
     * lists movies under a duration specified by the user, can also sort the output (but not change anything in the database or playlists)
     */
    private void listMoviesUnderDuration()
    {
        System.out.println("\nTo cancel, type a negative number.");
        System.out.print("Type the duration in minutes: ");
        double thresholdDuration = console.nextDouble(), duration;
        int id = 1, selectedSort;
        boolean matchFound = false;
        for (;;) //loop that will keep running until a valid answer is given
        {
            System.out.print("Sorting method (0:ID, 1: name, 2: director, 3: file size, 4: duration):");
            selectedSort = console.nextInt();
            if (selectedSort < 0 || selectedSort > 4)
            {
                System.out.println("Invalid input.");
                continue;
            }
            else
            {
                break;
            }
        }
        System.out.println();
        if (selectedSort == 0) //if the user chooses to sort by ID then just print all matches in the order they were stored in the database, else sort accordingly
        {
            while (id <= database.getMaxMovies()) //loop that searches for movies that match the criteria, then prints each one as they were found
            {
                duration = database.getMovieDuration(id);
                if (!(duration == 0) && duration < thresholdDuration) //check the duration
                {
                    System.out.print(getMovieDataFromDatabase(id));
                    matchFound = true;
                }
                id++;
            }
        }
        else
        {
            int[] ids = new int[database.getMaxMovies()];
            int counter = 0;
            while (id <= database.getMaxMovies()) //loop that searches for movies that match the criteria, then stores their id numbers in an array
            {
                duration = database.getMovieDuration(id);
                if (!(duration == 0) && duration < thresholdDuration) //check the duration
                {
                    ids[counter] = id;
                    matchFound = true;
                    counter++;
                }
                id++;
            }
            if (matchFound) //if at least one movie match the criteria then sort the array based on the key the user specified, then print the movies based on the order in the array
            {
                ids = sortArrayOfIds(ids, counter, selectedSort);
                for (counter = 0; counter < ids.length; counter++)
                {
                    System.out.print(getMovieDataFromDatabase(ids[counter]));
                }
            }
        }
        if (!matchFound) //if no matches were found tell the user
        {
            System.out.println("No movies with duration under " + thresholdDuration + " minutes found in the database.");
        }
    }
    
    /*
     * selects which way to sort the array based on the sortType parameter, then calls the correct method
     * sortType parameter must be any of 1,2,3,4 (name, director, duration and file size respectively)
     * aLogicalSize parameter is the logical size of the array parameter (is used to stop the sorting loop)
     * assumes that the list of ids in the array do not contain any blank spaces in between (but automatically ignores any beyond the logical size)
     */
    private int[] sortArrayOfIds(int[] a, int aLogicalSize, int sortType)
    {
        switch (sortType)
        {
            case 1:     a = sortArrayOfIdsByName(a, aLogicalSize);
                        break;
            case 2:     a = sortArrayOfIdsByDirector(a, aLogicalSize);
                        break;
            case 4:     a = sortArrayOfIdsByFileSize(a, aLogicalSize);
                        break;
            case 3:     a = sortArrayOfIdsByDuration(a, aLogicalSize);
                        break;
            default:    return null;
        }
        return a;
    }
    
    /*
     * sorts an array of movie ids by name in alphabetical order
     */
    private int[] sortArrayOfIdsByName(int[] a, int aLogicalSize)
    {
        int[] result = new int[aLogicalSize];
        int counter, minIndex, selectedIndex;
        String name1, name2;
        for(counter = 0; counter < aLogicalSize; counter++) //the main loop, stops once the result array has been filled
        {
            minIndex = 0;
            while (a[minIndex] == 0) //make sure minIndex is not referring to a nonexistent movie
            {
                minIndex++;
            }
            selectedIndex = 1;
            while (selectedIndex < aLogicalSize) //searches for the movie that would be first in the array
            {
                if (a[selectedIndex] != 0) //make sure selectedIndex is not referring to a nonexistent movie
                {
                    name1 = database.getMovieName(a[minIndex]);
                    name2 = database.getMovieName(a[selectedIndex]);
                    if (name2.compareToIgnoreCase(name1) < 0)
                    {
                        minIndex = selectedIndex;
                    }
                }
                selectedIndex++;
            }
            result[counter] = a[minIndex];
            a[minIndex] = 0; //clears the element previously identified by the above loop, so the loop will find the next
        }
        return result;
    }
    
    /*
     * sorts an array of movie ids by director in alphabetical order
     * works exactly the same way as the sortArrayOfIdsByName method, except that this compares the directors instead of the names
     */
    private int[] sortArrayOfIdsByDirector(int[] a, int aLogicalSize)
    {
        int[] result = new int[a.length];
        int counter, minIndex, selectedIndex;
        String director1, director2;
        for(counter = 0; counter < aLogicalSize; counter++)
        {
            minIndex = 0;
            while (a[minIndex] == 0)
            {
                minIndex++;
            }
            selectedIndex = 1;
            while (selectedIndex < aLogicalSize)
            {
                if (a[selectedIndex] != 0)
                {
                    director1 = database.getMovieDirector(a[minIndex]);
                    director2 = database.getMovieDirector(a[selectedIndex]);
                    if (director2.compareToIgnoreCase(director1) < 0)
                    {
                        minIndex = selectedIndex;
                    }
                }
                selectedIndex++;
            }
            result[counter] = a[minIndex]; 
            a[minIndex] = 0;
        }
        return result;
    }
    
    /*
     * sorts an array of movie ids by file size in ascending order
     * works almost exactly the same way as the sortArrayOfIdsByName method, except this compares the file sizes
     */
    private int[] sortArrayOfIdsByFileSize(int[] a, int aLogicalSize)
    {
        int[] result = new int[a.length];
        int counter, minIndex, selectedIndex;
        double size1, size2;
        for(counter = 0; counter < aLogicalSize; counter++)
        {
            minIndex = 0;
            while (a[minIndex] == 0) 
            {
                minIndex++;
            }
            selectedIndex = 1;
            while (selectedIndex < aLogicalSize)
            {
                if (a[selectedIndex] != 0) 
                {
                    size1 = database.getMovieFileSize(a[minIndex]);
                    size2 = database.getMovieFileSize(a[selectedIndex]);
                    if (size1 > size2)
                    {
                        minIndex = selectedIndex;
                    }
                }
                selectedIndex++;
            }
            result[counter] = a[minIndex]; 
            a[minIndex] = 0; 
        }
        return result;
    }
    
    /*
     * sorts an array of movie ids by duration in ascending order
     * works almost exactly the same way as the sortArrayOfIdsByName method, except this compares the durations
     */
    private int[] sortArrayOfIdsByDuration(int[] a, int aLogicalSize)
    {
        int[] result = new int[a.length];
        int counter, minIndex, selectedIndex;
        double time1, time2;
        for(counter = 0; counter < aLogicalSize; counter++)
        {
            minIndex = 0;
            while (a[minIndex] == 0)
            {
                minIndex++;
            }
            selectedIndex = 1;
            while (selectedIndex < aLogicalSize)
            {
                if (a[selectedIndex] != 0)
                {
                    time1 = database.getMovieDuration(a[minIndex]);
                    time2 = database.getMovieDuration(a[selectedIndex]);
                    if (time1 > time2)
                    {
                        minIndex = selectedIndex;
                    }
                }
                selectedIndex++;
            }
            result[counter] = a[minIndex]; 
            a[minIndex] = 0; 
        }
        return result;
    }
    
    /*
     * returns a string for display in a terminal
     */
    private String getMovieDataFromDatabase(int id)
    {
        if (!database.isMovieEmpty(id)) //if the movie is empty/nonexistent return nothing, else return a string formatted for display in terminal
        {
            return "ID:" + id + " " + database.getMovieName(id) + ", directed by " + database.getMovieDirector(id) + ", duration: " + database.getMovieDuration(id) + " minutes, file size: " + database.getMovieFileSize(id) + " MB\n";
        }
        else
        {
            return "";
        }
    }
    
    /*
     * returns a string for display in a terminal
     */
    private String getMovieDataFromPlaylist(Playlist p, int slotId)
    {
        if (!p.isSlotEmpty(slotId)) //if the slot is empty/nonexistent return nothing, else return a string formatted for display in terminal
        {
            return slotId + ". " + p.getMovieName(slotId) + ", directed by " + p.getMovieDirector(slotId) + ", duration: " + p.getMovieDuration(slotId) + " minutes, file size: " + p.getMovieFileSize(slotId) + " MB\n";
        }
        else
        {
            return slotId + ". Empty slot\n";
        }
    }
    
    /*
     * returns a string for display in a terminal
     */
    private String getPlaylistData(Playlist p)
    {
        return "duration: " + p.getPlaylistDuration() + " minutes, size: " + p.getPlaylistSize() + " MB";
    }
    
    /*
     * lists the contents of the playlist referenced by the parameter
     */
    private void listPlaylistContents(Playlist p)
    {
        int id = 1;
        System.out.println();
        while (id <= p.getMaxMovies()) //loop that prints all the contents of the playlist, including empty slots
        {
            System.out.print(getMovieDataFromPlaylist(p,id));
            id++;
        }
    }
    
    /*
     * lists all playlists and their contents
     */
    private void listAllPlaylistsAndContents()
    {
        Playlist p;
        int id = 1;
        while (id <= playlistAmount) //loop that prints each existing playlist and its contents
        {
            p = idPlaylist(id);
            if (!p.isEmpty()) //if the playlist is empty don't show it (considered nonexistent)
            {
                System.out.println("\nPlaylist " + id + ", " + getPlaylistData(p));
                listPlaylistContents(p);
            }
            id++;
        }
    }
    
    /*
     * asks the user which playlist to list the contents of, then calls listPlaylistContents
     */
    private void listOnePlaylistAndContents()
    {
        Playlist p = selectPlaylist(); //asks user which playlist to show
        if (p == null)
        {
            return; 
        }
        listPlaylistContents(p);
    }
    
    /*
     * lists all playlists, but not their contents
     * can be used when user input is required on which playlist should be selected
     */
    private void listAllPlaylists()
    {
        Playlist p;
        int id = 1;
        System.out.println();
        while (id <= playlistAmount) //loop that prints all the existing playlists (those with at least one movie)
        {
            p = idPlaylist(id);
            if (!p.isEmpty())
            {
                System.out.println("Playlist " + id + ", " + getPlaylistData(p));
            }
            id++;
        }
    }
    
    /*
     * returns the playlist object referenced by the playlist id number
     */
    private Playlist idPlaylist(int playlistId)
    {
        if (playlistId >= 1 && playlistId <= playlistAmount) //check if id is valid, returns the Playlist object if it is, returns null if not
        {
            return playlists[playlistId - 1]; //id - 1 == index
        }
        else
        {
            return null;
        }
    }
    
    /*
     * asks the user which playlist he/she wants to select, then returns the selected playlist object
     */
    private Playlist selectPlaylist()
    {
        Playlist p;
        for(int id;;) //loop to keep asking user until valid input is received
        {
            listAllPlaylists();
            System.out.println("\nTo cancel, type -1 as the number of the playlist.");
            System.out.print("Type the number of the playlist: ");
            id = console.nextInt();
            if (id == -1)
            {
                return null;
            }
            p = idPlaylist(id);
            if (p == null || p.isEmpty())
            {
                System.out.println("\nSelected playlist does not exist.");
                continue;
            }
            else
            {
                return p;
            }
        }
    }
    
    /*
     * resizes a Playlist array, has two modes
     * extend mode (extend is true) will extend the array by PLAYLIST_EXTEND_ARRAY_SIZE
     * extend mode assumes that the input array is full
     * shrink mode (extend is false) will either reduce the array to half its current size or the default size, whichever is larger
     * shrink mode will not preserve any empty spots in between playlists (playlists 1,3,5 will become playlists 1,2,3 after the resize for example)
     * shrink mode assumes that the logical size of the input array is less than half the physical size
     */
    private Playlist[] resizeArray(boolean extend, Playlist[] array)
    {
        Playlist[] result;
        if (extend) //selects the mode, if true then extends the array, else it shrinks the array
        {
            result = new Playlist[array.length + PLAYLIST_EXTEND_ARRAY_SIZE]; //create an array of the new size
            int counter = 0;
            for (;counter < array.length; counter++) //loop that copies the elements of the original array into the extended array, preserving order
            {
                result[counter] = array[counter];
            }
            int endCounter = counter + PLAYLIST_EXTEND_ARRAY_SIZE;
            for (;counter < endCounter; counter++) //loop that initializes the newly added elements
            {
                result[counter] = new Playlist();
            }
        }
        else
        {
            int counter = 0, resultIndex = 0;
            if (array.length % 2 == 0) //checks if the physical size of the array is an even number
            {
                result = new Playlist[Math.max(array.length / 2, DEFAULT_PLAYLIST_AMOUNT)]; //decides whether to halve the size of the array or set it to the default size, whichever is higher
                for (;counter < array.length; counter++) //loop that copies the non-empty elements from the original array to the new one
                {
                    if (!array[counter].isEmpty()) //checks if the playlist to be copied is empty, copies it if true
                    {
                        result[resultIndex] = array[counter];
                        resultIndex++;
                    }
                }
                for (;resultIndex < result.length; resultIndex++) //initializes remaining objects, if any
                {
                    result[resultIndex] = new Playlist();
                }
            }
            else
            {
                result = new Playlist[Math.max((array.length / 2) + 1, DEFAULT_PLAYLIST_AMOUNT)]; //decides whether to halve the size of the array (rounded up) or set it to the default size, whichever is higher
                for (;counter < array.length; counter++) //loop that copies the non-empty elements from the original array to the new one
                {
                    if (!array[counter].isEmpty()) //checks if the playlist to be copied is empty, copies it if true
                    {
                        result[resultIndex] = array[counter];
                        resultIndex++;
                    }
                }
                for (;resultIndex < result.length; resultIndex++) //initializes remaining objects, if any
                {
                    result[resultIndex] = new Playlist();
                }
            }
        }
        playlistAmount = result.length; //updates the playlistAmount variable
        return result;
    }
    
    /*
     * saves the current database into a file in the same directory as the program with the file name specified by the user
     */
    private void saveDatabase()
    {
        System.out.println("\nTo cancel, leave the file name blank.");
        System.out.println("Type the name of the file you wish to save the database into:");
        console.nextLine();
        String fileName = console.nextLine();
        if (fileName.equals(""))
        {
            return;
        }
        try
        {
            outputStream = new PrintWriter (fileName);
        }
        catch (FileNotFoundException e)
        {
            System.out.println("Error: File not found"); 
            return;
        }
        for (int id = 1; id <= database.getMaxMovies(); id++) //loop that stores all the movie attributes in the file
        {
            if (database.isMovieEmpty(id)) //if the movie is empty don't add it into the file
            {
                continue;
            }
            outputStream.println("Movie title: " + database.getMovieName(id));
            outputStream.println("Director: " + database.getMovieDirector(id));
            outputStream.println("fileSize: " + database.getMovieFileSize(id));
            outputStream.println("duration: " + database.getMovieDuration(id));
            outputStream.println();
        }
        outputStream.close();
    }
    
    /*
     * loads a database from a file in the same directory as the program with the file name specified by the user
     * returns true if at least one movie was successfully loaded from the file, false otherwise
     * assumes that the duration is always the last entry for a single movie in the file
     */
    private boolean loadDatabase()
    {
        System.out.println("\nAll movies in the current database (if any) will be lost if not saved.");
        System.out.println("To cancel, leave the file name blank.");
        System.out.println("Type the name of the file that contains the movie database:");
        console.nextLine();
        String fileName = console.nextLine();
        if (fileName.equals(""))
        {
            return false;
        }
        try
        {
            inputStream = new Scanner(new File(fileName));
        }
        catch (FileNotFoundException e)
        {
            System.out.println("Error: File not found");
            return false;
        }
        database.setEmpty(); //clear the database before loading the database
        String line, name = "", director = "";
        double fileSize = 0, duration = 0;
        boolean success = false;
        while (inputStream.hasNextLine()) //loop that reads each line and stores the movie attributes, then adds a movie with those attributes
        {
            line = inputStream.nextLine();
            if (line.startsWith("Movie title: ")) //if the line starts with "Movie title: " then it has the name of the movie
            {
                name = line.substring(13);
                continue;
            }
            if (line.startsWith("Director: ")) //if the line starts with "Director: " then it has the director of the movie
            {
                director = line.substring(10);
                continue;
            }
            if (line.startsWith("fileSize: ")) //if the line starts with "fileSize: " then it has the file size of the movie
            {
                fileSize = Double.parseDouble(line.substring(10));
                continue;
            }
            if (line.startsWith("duration: ")) //if the line starts with "duration: " then it has the duration of the movie, and it also indicates that the movie attributes are complete
            {
                duration = Double.parseDouble(line.substring(10));
                if (database.isFull()) //if the database is full extend it
                {
                    database.extendArray();
                }
                if (database.addMovie(name, director, fileSize, duration).substring(6,11).equals("added")) //adds the movie, if successful set the boolean variable success as true
                {
                    success = true;
                }
            }
        }
        inputStream.close();
        return success;
    }
    
    /*
     * the core program loop is in the run method, the main method simply calls it
     */
    public static void main(String[] args){
        Interface intFace = new Interface();
        intFace.run();
    }
}
