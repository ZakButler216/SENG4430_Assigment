/*
 * PlanarShape
 * An abstract class which represents a two-dimensional shape and implements the Comparable interface
 * Author: Prajna Sariputra
 * Student Number: 3273420
 * Course: SENG2200
 * E-mail address: c3273420@uon.edu.au
 */

//shape factory 8:55AM April 3, 9:02AM April 3 finish (for P)

import java.util.Scanner;

public abstract class PlanarShape implements Comparable<PlanarShape> {

	/*
	 * The compared property is the result of area(), unless the values from this object and the parameter are
	 * within 0.005 units of each other, in which case originDistance() is used instead
	 * 
	 * Preconditions:
	 * area() and originDistance() have been implemented properly
	 * Postconditions:
	 * -1 is returned if the compared property of this object is less than that of the parameter,
	 * 1 is returned if the compared property of this object is more than that of the parameter,
	 * 0 is returned if the output of area() of this object and originDistance() is within 0.005 units of each other,
	 * and (this.originDistance() == right.originDistance()) returns true
	 */
	@Override
	public int compareTo(PlanarShape right) {
		double areaDiff = Math.abs((area() - right.area()));
		if (areaDiff < (0.005 * Math.max(area(), right.area()))) { //if area is considered equal check distance to origin
			if (originDistance() < right.originDistance()) {
				return -1;
			}
			else if (originDistance() > right.originDistance()) {
				return 1;
			}
			else {
				return 0;
			}
		}
		else { //else just check the area
			if (area() < right.area()) {
				return -1;
			}
			else {
				return 1;
			}
		}
	}
	
	/*
	 * Preconditions:
	 * Depending on the implementation
	 * Postconditions:
	 * Returns a String that contains a representation of the PlanarShape object
	 * (format depends on implementation)
	 */
	@Override
	public abstract String toString();
	
	/*
	 * Preconditions:
	 * Depending on the implementation
	 * Postconditions:
	 * Returns a double that contains the area of the PlanarShape object
	 */
	public abstract double area();
	
	/*
	 * Preconditions:
	 * Depending on the implementation
	 * Postconditions:
	 * Returns a double that contains the distance of the PlanarShape object to the origin
	 * (accuracy depends on the implementation)
	 */
	public abstract double originDistance();

	/*
	 * Preconditions:
	 * The input String starts with a letter representing a specific implementation of PlanarShape that is known
	 * (currently P for a Polygon, C for Circle and S for SemiCircle)
	 * Postconditions:
	 * A PlanarShape object is created based on the input String and returned
	 */
	public static PlanarShape shapeFactory(String in) {
		PlanarShape out;
		Scanner input = new Scanner(in);
		String type = input.next();
		switch (type) {
		case "P":
			out = new Polygon(in.substring(2));
			break;
		case "C":
			out = new Circle(in.substring(2));
			break;
		case "S":
			out = new SemiCircle(in.substring(2));
			break;
		default:
			input.close();
			throw new IllegalArgumentException("The parameter does not match any known PlanarShape types.");
		}
		input.close();
		return out;
	}
}
