
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.Scanner;

public class PA2 {

	public static void main(String[] args) {
		String fileName;
		if (args.length == 0) { //use test.dat as filename if no argument given
			fileName = "test.dat";
		}
		else {
			fileName = args[0];
		}
		Scanner file;
		try {
			file = new Scanner(new File(fileName));
		}
		catch (FileNotFoundException e) { //if file is not present tell user
			System.out.println("File not found");
			return;
		}
		LinkedList<PlanarShape> list = new LinkedList<PlanarShape>();
		SortedList<PlanarShape> sList = new SortedList<PlanarShape>();
		while (file.hasNextLine()) { //add every PlanarShape from the file into the unsorted list
			list.append(PlanarShape.shapeFactory(file.nextLine()));
		}
		Iterator<PlanarShape> iter = list.iterator();
		System.out.println("Original list:");
		PlanarShape temp;
		while (iter.hasNext()) { //print out the contents of the unsorted list and add each one to the sorted list
			temp = iter.next();
			System.out.println(temp.toString());
			sList.insertInOrder(temp);
		}
		System.out.println();
		file.close();
		iter = sList.iterator();
		System.out.println("Sorted list:");
		while (iter.hasNext()) { //print out the contents of the sorted list
			System.out.println(iter.next().toString());
		}
	}

}
