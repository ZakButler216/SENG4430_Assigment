/**
 * MovieDatabase
 * Manages several Movie objects, does not accept duplicate movies (same name, director, file size and duration)
 * Author: Prajna Sariputra
 * Student Number: C3273420
 * E-mail Address: c3273420@uon.edu.au
 * Last Changed: 26 May 2017
 */
public class MovieDatabase
{
    private Movie[] allMovies; //id is not the same as the array index (id starts with 1, index with 0)
    private int databaseSize; //physical size of the database
    private final int DEFAULT_SIZE = 4; //default initial size as well as minimum size
    private int logicalSize;
    private final int EXTEND_ARRAY_SIZE = 4;
    
    /*
     * default constructor, sets up the database with the default size initially
     */
    public MovieDatabase()
    {
        initializeDatabase(DEFAULT_SIZE);
    }
    
    /*
     * constructor that sets up the database with the parameter as the initial size (but when shrunk the minimum size will still be the default size, and if the parameter is smaller than the default size the default size will be used instead)
     */
    public MovieDatabase(int size)
    {
        if (size <= DEFAULT_SIZE)
        {
            initializeDatabase(DEFAULT_SIZE);
        }
        else
        {
            initializeDatabase(size);
        }
    }
    
    /*
     * initializes the allMovies array with the parameter as the initial size
     * can be used to reset the array as well (clear all the movies inside and set the size)
     */
    private void initializeDatabase(int size)
    {
        if (allMovies == null) //update the numberOfMovies static variable with the change (if the array has not been initialized yet then add the intended physical size, if it already has been initialized add or subtract the difference)
        {
            Movie.changeNumberOfMovies(true, size);
        }
        else
        {
            if (allMovies.length > size)
            {
                Movie.changeNumberOfMovies(false, allMovies.length - size);
            }
            if (allMovies.length < size)
            {
                Movie.changeNumberOfMovies(true, size - allMovies.length);
            }
        }
        allMovies = new Movie[size]; //initialize the array itself
        databaseSize = size;
        for (int index = 0; index < databaseSize; index++) //initialize all the objects in the array
        {
            allMovies[index] = new Movie();
        }
        logicalSize = 0;
    }
    
    /*
     * attempts to add the specified movie to the next available slot
     * returns the result of that attempt
     */
    public String addMovie(String newName, String newDirector, double newFileSize, double newDuration)
    {
        if (isDuplicate(newName,newDirector,newFileSize,newDuration)) //if the movie is already present return an error
        {
            return "Movie is already present in the database.";
        }
        int id = 1, setCode;
        Movie m;
        while (id <= databaseSize) //loop that searches for the next available slot in the database and adds the movie into it if possible
        {
            m = idMovie(id);
            if (m.isEmpty()) //if the slot is empty attempt to add the movie, if not skip it
            {
                setCode = m.setData(newName,newDirector,newFileSize,newDuration); //attempts to add the movie
                if (setCode == 0) //returns messages or errors depending on whether the attempt was successful
                {
                    logicalSize++;
                    return "Movie added to slot " + id + ".";
                }
                else
                {
                    if (setCode == 2)
                    {
                        return "File size and duration must be greater than zero.";
                    }
                    else
                    {
                        return "Name and director must not be empty.";
                    }
                }
            }
            id++;
        }
        return "Movie database full."; //if no attempt to add the movie was triggered it likely means that there are no empty slots left
    }
    
    /*
     * attempts to edit the movie with the specified id using the new attributes passed as the parameters (id will not be changed)
     * returns the result of that attempt
     * assumes that if any of the new attributes have invalid contents (name and director are empty, file size and duration is less than or equal to zero) then the attribute should be left unchanged
     */
    public String editMovie(int id, String newName, String newDirector, double newFileSize, double newDuration)
    {
        Movie m = idMovie(id);
        int changeCounter = 4;
        if (newName.equals("")) //if the name is blank then leave it unchanged and decrement changeCounter
        {
            newName = m.getName();
            changeCounter--;
        }
        if (newDirector.equals("")) //if the director is blank then leave it unchanged and decrement changeCounter
        {
            newDirector = m.getDirector();
            changeCounter--;
        }
        if (newFileSize <= 0) //if the file size is less than or equal to zero then leave it unchanged and decrement changeCounter
        {
            newFileSize = m.getFileSize();
            changeCounter--;
        }
        if (newDuration <= 0) //if the duration is less than or equal to zero then leave it unchanged and decrement changeCounter
        {
            newDuration = m.getDuration();
            changeCounter--;
        }
        if (changeCounter == 0) //if nothing was changed return a message
        {
            return "Movie unchanged.";
        }
        m.setData(newName, newDirector, newFileSize, newDuration); //actually edits the movie
        return "Movie successfully edited."; //if the program gets to this point without errors it means that it has been successful
    }
    
    public int getMaxMovies()
    {
        return databaseSize;
    }
    
    public int getLogicalSize()
    {
        return logicalSize;
    }
    
    public int getDefaultMaxMovies()
    {
        return DEFAULT_SIZE;
    }
    
    public String getMovieName(int id)
    {
        Movie m = idMovie(id);
        if (m == null)
        {
            return "";
        }
        String o = m.getName();
        return o;
    }

    public String getMovieDirector(int id)
    {
        Movie m = idMovie(id);
        if (m == null)
        {
            return "";
        }
        String o = m.getDirector();
        return o;
    }

    public double getMovieDuration(int id)
    {
        Movie m = idMovie(id);
        if (m == null)
        {
            return 0;
        }
        double o = m.getDuration();
        return o;
    }

    public double getMovieFileSize(int id)
    {
        Movie m = idMovie(id);
        if (m == null)
        {
            return 0;
        }
        double o = m.getFileSize();
        return o;
    }
    
    /*
     * returns the Movie object the id is referring to
     */
    private Movie idMovie(int id)
    {
        if (id >= 1 && id <= databaseSize)
        {
            return allMovies[id - 1]; //id - 1 == index
        }
        else
        {
            return null;
        }
    }
    
    /*
     * searches the database for the specified movie
     * returns true if a movie in the database has the same name, director, file size and duration as specified, false if none are found
     */
    public boolean isDuplicate(String newName, String newDirector, double newFileSize, double newDuration)
    {
        Movie m = new Movie(newName, newDirector, newFileSize, newDuration);
        Movie m1;
        int id = 1;
        while (id <= databaseSize) //loop that searches for the movie
        {
            m1 = idMovie(id);
            if (m.equals(m1)) //if a match was found return true (no need to search the rest)
            {
                return true;
            }
            id++;
        }
        return false; //if none are found return false
    }

    /*
     * checks if the database is empty (logicalSize equals zero), returns true if so
     */
    public boolean isEmpty()
    {
        if (logicalSize == 0)
        {
            return true;
        }
        return false;
    }

    /*
     * checks if the database is full (logicalSize equals the physical size), returns true if so
     */
    public boolean isFull()
    {
        if (logicalSize == databaseSize)
        {
            return true;
        }
        return false;
    }

    /*
     * checks if the movie with the given id is empty/nonexistent, returns true if so
     */
    public boolean isMovieEmpty(int id)
    {
        Movie m = idMovie(id);
        if (m == null)
        {
            return true;
        }
        return m.isEmpty();
    }

    /*
     * attempts to "delete" the specified movie from the database (set the slot empty)
     * returns the result of the attempt
     */
    public String removeMovie(int id)
    {
        Movie m = idMovie(id);
        if (m == null) //in case the id is invalid
        {
            return "Invalid movie specified";
        }
        m.setEmpty(); //sets the slot empty
        logicalSize--; //updates logicalSize
        return "Movie with ID: " + id + " deleted from the database.";
    }
    
    /*
     * checks whether the specified movie has theDirector as the director, returns true if so
     */
    public boolean movieEqualsDirector(String theDirector, int id)
    {
        Movie m = idMovie(id);
        if (m == null)
        {
            return false;
        }
        return m.equalsDirector(theDirector);
    }
    
    /*
     * empties the entire database and resets the size
     */
    public void setEmpty()
    {
        initializeDatabase(DEFAULT_SIZE);
    }
    
    /*
     * the two methods extendArray and shrinkArray are ways to allow other classes to resize the array
     * without letting them gain access to the allMovies array directly
     */
    public void extendArray()
    {
        allMovies = resizeArray(true, allMovies);
    }
    
    public void shrinkArray()
    {
        allMovies = resizeArray(false, allMovies);
    }
    
    /*
     * resizes a Movie array, has two modes
     * extend mode (extend is true) will extend the array by EXTEND_ARRAY_SIZE
     * extend mode assumes that the input array is full
     * shrink mode (extend is false) will either reduce the array to half its current size or the default size, whichever is larger
     * shrink mode will not preserve any empty slots in between filled ones (movies in slots 1,3,5 will be moved to slots 1,2,3 after the resize for example)
     * shrink mode assumes that the logical size of the input array is less than half the physical size
     */
    private Movie[] resizeArray(boolean extend, Movie[] array)
    {
        Movie[] result;
        if (extend) //selects the mode, if true then extends the array, else it shrinks the array
        {
            result = new Movie[array.length + EXTEND_ARRAY_SIZE]; //create an array of the new size
            int counter = 0;
            for (;counter < array.length; counter++) //loop that copies the elements of the original array into the extended array, preserving order
            {
                result[counter] = array[counter];
            }
            int endCounter = counter + EXTEND_ARRAY_SIZE;
            for (;counter < endCounter; counter++) //loop that initializes the newly added elements
            {
                result[counter] = new Movie();
            }
            Movie.changeNumberOfMovies(true, EXTEND_ARRAY_SIZE); //update the numberOfMovies static variable in the Movie class
        }
        else
        {
            int counter = 0, resultIndex = 0, endSize;
            if (array.length % 2 == 0) //checks if the physical size of the array is an even number
            {
                endSize = Math.max(array.length / 2, DEFAULT_SIZE); //decides whether to halve the size of the array or set it to the default size, whichever is higher
                Movie.changeNumberOfMovies(false, array.length - endSize); //update the numberOfMovies static variable in the Movie class
                result = new Movie[endSize];
                for (;counter < array.length; counter++) //loop that copies the non-empty elements from the original array to the new one
                {
                    if (!array[counter].isEmpty()) //checks if the movie to be copied is empty, copies it if true
                    {
                        result[resultIndex] = array[counter];
                        resultIndex++;
                    }
                }
                for (;resultIndex < result.length; resultIndex++) //initializes remaining objects, if any
                {
                    result[resultIndex] = new Movie();
                }
            }
            else
            {
                endSize = Math.max((array.length / 2) + 1, DEFAULT_SIZE); //decides whether to halve the size of the array (rounded up) or set it to the default size, whichever is higher
                Movie.changeNumberOfMovies(false, array.length - endSize); //update the numberOfMovies static variable in the Movie class
                result = new Movie[endSize];
                for (;counter < array.length; counter++) //loop that copies the non-empty elements from the original array to the new one
                {
                    if (!array[counter].isEmpty()) //checks if the movie to be copied is empty, copies it if true
                    {
                        result[resultIndex] = array[counter];
                        resultIndex++;
                    }
                }
                for (;resultIndex < result.length; resultIndex++) //initializes remaining objects, if any
                {
                    result[resultIndex] = new Movie();
                }
            }
        }
        databaseSize = result.length; //update the databaseSize variable
        return result;
    }
}
